import React from 'react'

export default function Buttons() {
  return (
    <div>Buttons</div>
  )
}
